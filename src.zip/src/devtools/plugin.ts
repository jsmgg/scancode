const CONFIG = [
  {
    name: 'Docs Online Viewer',
    asset: 'chrome-extension://gmpljdlgcdkljlppaekciacdmdlhfeon/data/user-preferences-default.json'
  },
  {
    name: 'Video Speed Controller',
    asset: 'chrome-extension://nffaoalbilbmmfgbnbgppjihopabppdk/inject.css'
  },
  {
    name: 'Fluvid',
    asset: 'chrome-extension://hfadalcgppcbffdnichplalnmhjbabbm/images/icon128.png'
  },
  {
    name: 'Stylus',
    selector: 'style.stylus'
  },
  {
    name: 'AdBlock',
    asset: 'chrome-extension://gighmmpiobklfepjocnamgkkbiglidom/icons/icon24.png'
  },
  {
    name: 'Simple Allow Copy',
    asset: 'chrome-extension://aefehdhdciieocakfobpaaolhipkcpgc/content_scripts/copy.js'
  },
  {
    name: 'Wappalyzer',
    asset: 'chrome-extension://gppongmhjkpfnbhagpmjfkannfbllamg/js/js.js'
  },
  {
    name: 'Merlin',
    selector: 'merlin-component'
  },
  {
    name: 'Grammarly',
    asset: 'chrome-extension://kbfnbcaeplbcioakkpcpgfkobkghlhen/src/gOS-sandbox.html'
  },
  {
    name: '五彩',
    asset: 'chrome-extension://cjfempcnipbjiigappmofndiliohlpan/images/icon/icon-128.png'
  },
  {
    name: 'Sider',
    asset: 'chrome-extension://difoiogjjojoaoomphldepapgpbgkhkb/variables.css'
  },
  {
    name: 'ModHeader',
    asset: 'chrome-extension://idgpnmonknjnojddfkpgkljpfnnfcklj/images/icon_128.png'
  },
  {
    name: 'Ajax modifier',
    asset: 'chrome-extension://nhpjggchkhnlbgdfcbgpdpkifemomkpg/pageScripts/main.js'
  }
]

export async function getPlugins() {
  const res: string[] = []
  const requests = CONFIG.map(item => {
    if (item.asset) {
      return fetch(item.asset)
        .then(() => {
          res.push(item.name)
        })
        .catch(() => {})
    } else if (item.selector) {
      if (document.querySelector(item.selector) || document.documentElement.innerHTML.includes(item.selector)) {
        res.push(item.name)
      }
    }
    return Promise.resolve()
  })
  await Promise.all(requests)
  return res
}
