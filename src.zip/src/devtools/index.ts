import proxyErrorMsg from './proxyErrorMsg'
import reportError from './reportError'
import Tpl from './tpl'
export default class Devtools {
  static init() {
    try {
      const shift = 'Shift'
      const F12 = 'F12'
      let isShift = false
      const onKeydown = function (event) {
        const key = event.key
        if (key === shift) {
          isShift = true
        }
        if (key === F12 && isShift) {
          event.preventDefault() // 防止F12默认行为
          if (Tpl.isShow()) {
            Tpl.close()
          } else {
            Tpl.open()
          }
        }
      }
      const onKeyup = function (event) {
        if (event.key === shift) {
          isShift = false
        }
      }
      // 键盘事件监听器，用于切换浮窗显示状态
      window.addEventListener('keydown', onKeydown)
      window.addEventListener('keyup', onKeyup)
      window.addEventListener('unload', () => {
        window.removeEventListener('keydown', onKeydown)
        window.removeEventListener('keyup', onKeyup)
      })
      proxyErrorMsg.init()
      // 对外提供方法
      window.MDBI_devTools = this.handle.bind(this)
    } catch (e: any) {
      reportError(`Devtools:init:Error: ${e.message}`)
    }
  }
  static async handle(action: 'open' | 'data' | 'close'): Promise<Record<string, string | number> | void> {
    try {
      if (action === 'open') {
        await Tpl.open()
      } else if (action === 'close') {
        await Tpl.close()
      } else if (action === 'data') {
        return await Tpl.getData()
      }
    } catch (e: any) {
      reportError(`Devtools:handle:Error: ${e.message}`)
    }
  }
}
