import WebProfiling from '../webProfiling/core'
export const isProd = ['production'].includes(window.__ENV__)

export default function reportError(errorMsg: string) {
  if (isProd) {
    WebProfiling.report(
      {
        webProfilingErrorLog: 1
      },
      {
        errorMsg
      }
    )
  } else {
    console.warn(errorMsg)
  }
}
