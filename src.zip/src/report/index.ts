import { normalizeSendBeaconParam, RAPTOR_HOST } from '../util'
import { KeyValueObj, ReportData } from '../types'

export default function sendBaconReporter(
  unload: boolean,
  {
    appKey,
    tags,
    indicators,
    extraData
  }: {
    appKey: string
    tags: KeyValueObj
    indicators: ReportData['indicators']
    extraData: Record<string, string | number>
  }
) {
  const reportUrl = `https://${RAPTOR_HOST}/api/metric?p=${appKey}&v=1`
  const reportParams = normalizeSendBeaconParam(indicators, tags, extraData)
  if (unload) {
    navigator.sendBeacon(reportUrl, reportParams)
  } else {
    fetch(reportUrl, {
      method: 'POST',
      body: reportParams
    }).catch(() => {})
  }
}
