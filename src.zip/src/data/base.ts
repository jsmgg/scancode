import { isProd } from '../util'
import sendBaconReporter from '../report'
import { MonitorConfig, KeyValueObj, BaseResultItem } from '../types'
import { Core } from '../index'
export default class Base {
  config: MonitorConfig
  isProd = isProd
  //页面是否显示在当前屏幕
  pageShow = document.visibilityState === 'visible' || !document.hidden
  // 是否是单次上报的指标
  singleReport = false
  //准备就绪 可以开始采集
  ready = false
  // 采集时间间隔 子类配置具体值
  updateTime = 1000
  // 上次采集时间
  preUpdateTime = 0
  // 指标维度值实时快照信息 子类必须配置具体字段
  snapshot = {}
  // 待上报的指标值
  result = {} as { [propName: string]: BaseResultItem[] }
  constructor(snapshot) {
    this.snapshot = snapshot
    // 初始化指标采集结果集
    this.result = Object.keys(this.snapshot).reduce((res, key) => {
      res[key] = []
      return res
    }, {})
  }
  async init(core: Core) {}
  onVisibilitychange(pageShow: boolean) {}
  beforeUpdate() {}
  //更新指标维度值
  update(time: number, tags: KeyValueObj): number {
    try {
      const self = this
      if (!self.ready || (time - self.preUpdateTime < self.updateTime && self.preUpdateTime !== 0)) return 0
      self.beforeUpdate()
      let sum = 0
      Object.keys(self.snapshot).forEach(key => {
        if (self.singleReport) {
          self.result[key] = [
            {
              value: self.snapshot[key],
              tags: tags
            }
          ]
        } else {
          self.result[key].push({
            value: self.snapshot[key],
            tags: tags
          })
        }
        sum += self.result[key].length
      })
      self.preUpdateTime = time
      self.afterUpdate()
      return sum
    } catch (e: any) {
      this.log(`base:update:Error: ${e.message}`)
      return 0
    }
  }
  afterUpdate() {}
  log(message: string) {
    try {
      const self = this
      if (self.isProd) {
        const config = self.config || {}
        const tags = self.config.tags || {}
        sendBaconReporter(false, {
          appKey: config.appKey,
          tags: Object.keys(tags).reduce((res, tag) => {
            res[tag] = typeof tags[tag] === 'function' ? tags[tag]() : tags[tag]
            return res
          }, {}),
          indicators: {
            webProfilingErrorLog: [1]
          },
          extraData: {
            message
          }
        })
      } else {
        console.error(message)
      }
    } catch (e: any) {
      console.error(`Base:log:Error: ${e.message} :: ${message}`)
    }
  }
  destroy() {}
}
