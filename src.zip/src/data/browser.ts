import Base from './base'

export type BrowserInfo = {
  browser: string
  browserVersion: string
}
// 系统信息采集
class Browser extends Base {
  updateTime = Infinity
  constructor() {
    super({
      browser: 'unknown',
      browserVersion: '0'
    } as BrowserInfo)
  }

  async init() {
    try {
      const browserInfo = this.getBrowserInfo()
      const snapshot = this.snapshot as BrowserInfo
      snapshot.browser = browserInfo.browser
      snapshot.browserVersion = browserInfo.browserVersion
      this.ready = true
    } catch (e: any) {
      this.log(`os:Error: ${e.message}`)
    }
  }

  private getBrowserInfo(userAgent: string = navigator.userAgent): BrowserInfo {
    const match = /(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i.exec(userAgent) || []
    const matchedBrowser = (match[1] || '').toLowerCase()
    const browserVersion = match[2] || '0'

    switch (matchedBrowser) {
      case 'mise':
      case 'trident':
        return { browser: 'IE', browserVersion }
      case 'edge':
        return { browser: 'Edge', browserVersion }
      case 'chrome':
        return { browser: 'Chrome', browserVersion }
      case 'firefox':
        return { browser: 'Firefox', browserVersion }
      case 'safari':
        return { browser: 'Safari', browserVersion }
      case 'opera':
        return { browser: 'Opera', browserVersion }
      default:
        return { browser: 'unknown', browserVersion: `0` }
    }
  }
}

export default Browser
