import Base from './base'
import { RAPTOR_HOST, formatTime, inIFrame } from '../util'
import { Core } from '../index'

// 假死次数统计
class Crash extends Base {
  updateTime = 0
  worker: Worker
  core: Core
  workerCode = `
  let timer;
  self.addEventListener('message', function(e) {
    const data = e.data;
    timer && clearTimeout(timer);
    if(!data.stop){
      timer = setTimeout(()=>{
        const ts = Math.floor(Date.now() / 1000)
        fetch(data.url, {
          method: 'POST',
          body: JSON.stringify({
            kvs:{
              crashCount:1
            },
            tags:{...data.tags},
            extraData: JSON.stringify({crashTime: data.time}),
            ts
          })
        })
      }, 2000)
    }
  }, false);
  `
  constructor() {
    super({})
  }
  async init(core: Core) {
    try {
      if (!window.Blob || !window.Worker || inIFrame()) return
      const self = this
      const blob = new Blob([self.workerCode], { type: 'text/javascript' })
      const workerURL = URL.createObjectURL(blob)
      this.worker = new Worker(workerURL)
      this.core = core
      // 刷新页面如果有弹框，会导致帧动画函数停止执行
      const onBeforeunload = () => {
        self.proxyFun()
      }
      window.addEventListener('beforeunload', onBeforeunload)
      const alert = window.alert
      window.alert = function (...args) {
        self.proxyFun()
        return alert.apply(window, args)
      }
      const confirm = window.confirm
      window.confirm = function (...args) {
        self.proxyFun()
        return confirm.apply(window, args)
      }
      self.destroy = function () {
        window.removeEventListener('beforeunload', onBeforeunload)
      }
      this.ready = true
    } catch (e: any) {
      this.log(`Crash:init:Error: ${e.message}`)
    }
  }
  private proxyFun() {
    const self = this
    self.worker.postMessage(self.getMessage(true))
    setTimeout(() => {
      self.pageShow && self.worker.postMessage(self.getMessage(false))
    }, 1000)
  }
  private getReportUrl() {
    return `https://${RAPTOR_HOST}/api/metric?p=${this.core.config.appKey}&v=1`
  }
  private getMessage(stop) {
    try {
      const self = this
      return {
        tags: self.core.getSystemDimensions(),
        stop: stop,
        time: formatTime(Date.now()),
        url: self.getReportUrl()
      }
    } catch (e: any) {
      this.log(`Crash:getMessage:Error: ${e.message}`)
      return {}
    }
  }
  onVisibilitychange(pageShow: boolean) {
    const self = this
    if (self.worker) {
      self.worker.postMessage(self.getMessage(!pageShow))
    }
  }
  update(): number {
    const self = this
    if (self.ready && self.worker) {
      self.worker.postMessage(self.getMessage(!self.pageShow))
    }
    return 0
  }
}

export default Crash
