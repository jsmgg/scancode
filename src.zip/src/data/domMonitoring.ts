import _ from 'lodash'
import Base from './base'
import { getDomNumber, pageStable } from '../util'
export type DomMonitoringInfo = {
  domNumber: number
  domChangeFrequency: number
}

type DomMonitoringGroupResult = {
  domNumbers: number[]
  domChangeFrequencys: number[]
}

// dom数和dom变化频率
class DomMonitoring extends Base {
  updateTime = 1000 * 60
  groupResult = {
    domNumbers: [],
    domChangeFrequencys: []
  } as DomMonitoringGroupResult
  constructor() {
    super({ domNumber: 0, domChangeFrequency: 0 } as DomMonitoringInfo)
    try {
      if ('MutationObserver' in window && typeof window.MutationObserver === 'function') {
        pageStable.then(() => {
          this.bindObserver()
        })
      }
    } catch (e: any) {
      this.log(`domMonitoring:init:Error: ${e.message}`)
    }
  }
  private bindObserver() {
    const self = this
    let timer
    let result = 0
    const observer = new MutationObserver((e: MutationRecord[]) => {
      if (!self.pageShow) return
      timer && clearTimeout(timer)
      result += e.length
      timer = setTimeout(() => {
        self.groupResult.domNumbers.push(getDomNumber())
        self.groupResult.domChangeFrequencys.push(result)
        result = 0
        self.ready = true
      })
    })
    observer.observe(document.body, {
      childList: true, // 监视子节点的变化
      attributes: true, // 监视属性的变化
      characterData: true, // 监视节点内部的文本内容变化
      subtree: true // 将监视应用于所有后代节点
    })
    self.destroy = function () {
      observer.disconnect()
    }
  }
  beforeUpdate(): void {
    try {
      const self = this
      const snapshot = self.snapshot as DomMonitoringInfo
      snapshot.domNumber = self.groupResult.domNumbers.length
        ? (_.max<number>(self.groupResult.domNumbers) as number)
        : getDomNumber()
      snapshot.domChangeFrequency = self.groupResult.domChangeFrequencys.length
        ? (_.max<number>(self.groupResult.domChangeFrequencys) as number)
        : 0
      self.groupResult.domChangeFrequencys = []
      self.groupResult.domNumbers = []
    } catch (e: any) {
      this.log(`domMonitoring:beforeUpdate:Error: ${e.message}`)
    }
  }
}

export default DomMonitoring
