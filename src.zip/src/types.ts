export type KeyValueObj = Record<string, string | number>
export type RunTime = 'vue' | 'react'
type TagItem<T> = T | (() => T)

export type BaseResultItem = {
  value: number | string
  tags: KeyValueObj
}

export type ReportDataTags = {
  grayCell?: TagItem<string>
  subApp?: TagItem<string>
  misId?: TagItem<string>
  runTime?: TagItem<RunTime>
  url?: TagItem<string>
  webVersion?: TagItem<string>
  [customGlobalTag: string]: any
}

export type MonitorConfig = {
  appKey: string
  Vue?: unknown
  React?: unknown
  tags: ReportDataTags
}
export type CustomIndicator = {
  indicator: KeyValueObj
  tags: KeyValueObj
}

export type ReportData = {
  indicators: {
    [key: string]: Array<number | string>
  }
  tags: KeyValueObj
}

export type DurationIndicators = {
  indicator: string
  value: number
  tags: KeyValueObj
}
