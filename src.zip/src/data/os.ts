import Base from './base'

export type OsInfo = {
  systemOs: string
  systemOsVersion: string
}

const DefaultOs = 'Other'

// 操作系统信息的映射规则
const osMapping = [
  { name: 'Android', regex: /Android ([\d.]+)/ },
  { name: 'IOS', regex: /OS ([\d._]+)/, platforms: ['iPhone', 'iPad'] },
  { name: 'Windows', regex: /Windows NT ([\d._]+)/ },
  { name: 'MacOS', regex: /Mac OS X ([\d._]+)/ },
  { name: 'OpenHarmony', regex: /OpenHarmony ([\d._]+)/ },
  { name: 'Linux', regex: /Linux (x[\d._]+)/ }
]
// 系统信息采集
class OS extends Base {
  updateTime = Infinity

  constructor() {
    super({
      systemOs: DefaultOs,
      systemOsVersion: '0'
    } as OsInfo)
  }

  async init() {
    try {
      const ua = window.navigator.userAgent
      const snapshot = this.snapshot as OsInfo

      osMapping.forEach(os => {
        const isPlatformMatched = os.platforms
          ? os.platforms.some(platform => ua.includes(platform)) && ua.match(os.regex)
          : ua.match(os.regex)
        if (isPlatformMatched) {
          snapshot.systemOs = os.name
          snapshot.systemOsVersion = isPlatformMatched[1] || DefaultOs
        }
      })

      this.ready = true
    } catch (e: any) {
      this.log(`os:Error: ${e.message}`)
    }
  }
}

export default OS
