import Base from './base'

interface NewPerformanceEntry extends PerformanceEntry {
  //https://www.w3.org/TR/resource-timing/#dom-performanceresourcetiming-initiatortype
  initiatorType:
    | 'navigation'
    | 'css'
    | 'script'
    | 'xmlhttprequest'
    | 'fetch'
    | 'beacon'
    | 'video'
    | 'audio'
    | 'track'
    | 'img'
    | 'image'
    | 'input'
    | 'a'
    | 'iframe'
    | 'frame'
    | 'other'
  transferSize: number
}
// 接口请求、页面资源体积监控 体积单位：KB
class RequestConcurrency extends Base {
  updateTime = 1000 * 10
  singleReport = true
  requestType = ['fetch', 'xmlhttprequest', 'iframe', 'beacon']
  logNamePrefix = [
    'https://lx1.meituan.net',
    'https://plx.meituan.com',
    'https://catfront.dianping.com',
    'https://catfront.51ping.com'
  ]
  staticResourceType = ['css', 'script', 'image', 'img', 'link']

  constructor() {
    super({ requestConcurrency: 0, logRequestConcurrency: 0, pageResourceVolume: 0 })
    this.start()
  }
  private start() {
    if (!performance.getEntries || !performance.getEntriesByType) return
    const self = this
    window.addEventListener('DOMContentLoaded', function onLoad() {
      const resources = self.getResources() as NewPerformanceEntry[]
      self.loop(performance.now(), resources)
      window.removeEventListener('DOMContentLoaded', onLoad)
    })
  }
  private getResources(): NewPerformanceEntry[] {
    const resources = new Set()
    const resourcesEntries = performance.getEntries() as NewPerformanceEntry[]
    const resourcesByType = performance.getEntriesByType('resource') as NewPerformanceEntry[]
    return [...resourcesEntries, ...resourcesByType].filter(item => {
      if (!resources.has(item.name)) {
        resources.add(item.name)
        return true
      }
      return false
    })
  }
  // 每500毫秒判断一次有没有新请求，没有了就认定平稳了，超过3秒不再轮训
  private loop(startTime, resources: NewPerformanceEntry[]) {
    setTimeout(() => {
      try {
        const nowResources = this.getResources() as NewPerformanceEntry[]
        if (resources.length === nowResources.length || performance.now() - startTime > 3000) {
          setTimeout(() => {
            this.changeSnapshot(nowResources)
          })
        } else {
          this.loop(startTime, nowResources)
        }
      } catch (e: any) {
        this.log(`Request:loop:Error: ${e.message}`)
      }
    }, 500)
  }
  private byteToKb(byte: number): number {
    return (byte / 1024) | 0
  }
  private changeSnapshot(resources: NewPerformanceEntry[]) {
    const snapshot = this.snapshot as {
      requestConcurrency: number
      logRequestConcurrency: number
      pageResourceVolume: number
    }
    const requests: PerformanceEntry[] = resources.filter((item: NewPerformanceEntry) =>
      this.requestType.includes(item.initiatorType)
    )
    //请求并发量
    snapshot.requestConcurrency = requests.length
    // 日志请求并发量
    snapshot.logRequestConcurrency = requests.filter((item: PerformanceEntry) => {
      return this.logNamePrefix.some(prefix => item.name.startsWith(prefix))
    }).length
    // 页面资源体积
    const pageResourceVolume = resources
      .filter((item: NewPerformanceEntry) => this.staticResourceType.includes(item.initiatorType))
      .reduce((total, item) => total + (item.transferSize || 0), 0)
    snapshot.pageResourceVolume = this.byteToKb(pageResourceVolume)
    this.ready = true
  }
}

export default RequestConcurrency
