import _ from 'lodash'
import Base from './base'
// watch触发频率
class WatchChange extends Base {
  updateTime = 1000 * 60
  groupResult = {
    watchChangeFrequencys: [] as number[]
  }
  total = 0
  timer: any
  constructor() {
    super({ watchChangeFrequency: 0 })
  }

  async init() {
    try {
      const self = this
      const { config } = self
      if (config && config.tags.runTime) {
        const runTime = typeof config.tags.runTime === 'function' ? config.tags.runTime() : config.tags.runTime
        if (`${runTime}`.toLocaleLowerCase() === 'vue' && config.Vue) {
          const vue = config.Vue as { version: string }
          if (`${vue.version}`.startsWith('2.6.')) {
            this.proxyVue(config.Vue)
          }
        }
      }
    } catch (e: any) {
      this.log(`watchChange:init:Error: ${e.message}`)
    }
  }
  beforeUpdate(): void {
    const snapshot = this.snapshot as { watchChangeFrequency: number }
    snapshot.watchChangeFrequency = this.groupResult.watchChangeFrequencys.length
      ? (_.max<number>(this.groupResult.watchChangeFrequencys) as number)
      : 0
    this.groupResult.watchChangeFrequencys = []
  }
  private proxyVue(Vue) {
    try {
      const self = this
      Vue.prototype.$watch = this.proxyWatch(Vue.prototype.$watch)
      self.ready = true
    } catch (e: any) {
      this.log(`watchChange:proxyVue:Error: ${e.message}`)
    }
  }
  // 代理$watch方法 主要为了收集 watcher 实现watcher.run的代理
  private proxyWatch($watch) {
    const self = this
    return function (...args: any[]) {
      //@ts-ignore
      const vm = this
      const res = $watch.call(vm, ...args)
      try {
        const watchers = vm._watchers
        if (watchers) {
          watchers.forEach(watcher => {
            if (watcher.run._monitory_proxy) return
            watcher.run = self.proxyWatchRun(watcher.run, watcher)
            watcher.run._monitory_proxy = true
          })
        }
        return res
      } catch (e: any) {
        self.log(`WatchChange:proxyWatch:Error ${e.message}`)
      }
      return res
    }
  }
  private proxyWatchRun(run, watcher) {
    const self = this
    return function (...args) {
      const result = run.call(watcher, ...args)
      try {
        self.total++
        self.timer && clearTimeout(self.timer)
        self.timer = setTimeout(() => {
          self.groupResult.watchChangeFrequencys.push(self.total)
          self.total = 0
        })
      } catch (e: any) {
        self.log(`WatchChange:proxyWatchRun:Error ${e.message}`)
      }
      return result
    }
  }
}

export default WatchChange
