import Base from './base'
const indicators = {
  jsHeapSizeLimit: 0, //可用内存
  usedJSHeapSize: 0, //已用内存
  maximumMemory: 0, //内存峰值
  memoryStableValue: 0, //内存稳定值
  freeMemory: 0, //空闲内存
  freeMemoryRate: 0, //内存空闲率
  usedMemoryRate: 0, //内存使用率
  maxUsedMemoryRate: 0, //内存使用率峰值
  usedMemoryRateStableValue: 0 //内存使用率稳定值
}
// 内存使用情况统计
class Memory extends Base {
  updateTime = 1000 * 60
  // 存一分钟内采集样本
  groupResult = {
    jsHeapSizeLimits: [] as number[],
    usedJSHeapSizes: [] as number[]
  }
  constructor() {
    super({ ...indicators })
  }

  async init() {
    if (performance && (performance as any).memory && (performance as any).memory.jsHeapSizeLimit) {
      this.ready = true
      this.loop()
    }
  }
  private loop() {
    const self = this
    self.pageShow && self.addPoint()
    setTimeout(() => {
      self.loop()
    }, 1000)
  }
  private addPoint() {
    //@ts-ignore
    const memory = performance.memory as {
      jsHeapSizeLimit: number
      usedJSHeapSize: number
    }
    const { jsHeapSizeLimit, usedJSHeapSize } = memory
    if (jsHeapSizeLimit && usedJSHeapSize) {
      this.groupResult.jsHeapSizeLimits.push(jsHeapSizeLimit)
      this.groupResult.usedJSHeapSizes.push(usedJSHeapSize)
    }
  }
  private byteToMb(byte: number): number {
    return (byte / 1024 / 1024) | 0
  }
  //收集样本之前计算一次均值和top值
  beforeUpdate() {
    try {
      const { jsHeapSizeLimits, usedJSHeapSizes } = this.groupResult
      if (!jsHeapSizeLimits.length || !usedJSHeapSizes.length) return
      const result = {
        jsHeapSizeLimit: 0, //可用内存 [平均值]
        usedJSHeapSize: 0, //已用内存  [平均值]
        maximumMemory: 0, //内存峰值   [最大值]
        memoryStableValue: 0, //内存稳定值  [出现最多次数的值]
        freeMemory: 0, //空闲内存 [平均值]
        freeMemoryRate: 0, //内存空闲率  [平均值]
        usedMemoryRate: 0, //内存使用率   [平均值]
        maxUsedMemoryRate: 0, //内存使用率峰值  [最大值]
        usedMemoryRateStableValue: 0 //内存使用率稳定值  [出现最多次数的值, 百分比取整]
      }
      const count = jsHeapSizeLimits.length
      const memoryStableValueMap = {}
      const usedMemoryRateStableValueMap = {}
      let maximumMemory = 0
      let memoryStableValueCount = 0
      let memoryStableValue = 0
      let usedJSHeapSizesSum = 0
      let maxUsedMemoryRate = 0
      let usedMemoryRateStableValueCount = 0
      let usedMemoryRateStableValue = 0

      const jsHeapSizeLimitsSum = jsHeapSizeLimits.reduce((sum, num) => {
        return sum + num
      }, 0)
      usedJSHeapSizes.forEach(num => {
        // 最大使用内存
        maximumMemory = Math.max(maximumMemory, num)
        // 平稳值精确到mb
        const stableValue = this.byteToMb(num) || 0
        memoryStableValueMap[stableValue] = memoryStableValueMap[stableValue]
          ? memoryStableValueMap[stableValue] + 1
          : 1
        // 计算内存平稳值
        if (memoryStableValueCount < memoryStableValueMap[stableValue]) {
          memoryStableValueCount = memoryStableValueMap[stableValue]
          memoryStableValue = stableValue
        }
        usedJSHeapSizesSum += num
      })

      result.jsHeapSizeLimit = this.byteToMb(jsHeapSizeLimitsSum / count)
      result.usedJSHeapSize = this.byteToMb(usedJSHeapSizesSum / count)
      result.maximumMemory = this.byteToMb(maximumMemory)
      result.memoryStableValue = memoryStableValue
      result.freeMemory = this.byteToMb((jsHeapSizeLimitsSum - usedJSHeapSizesSum) / count)
      result.freeMemoryRate =
        ((usedJSHeapSizes.reduce((sum, num, index) => {
          return sum + (1 - num / jsHeapSizeLimits[index])
        }, 0) /
          count) *
          1000) |
        0
      result.usedMemoryRate =
        ((usedJSHeapSizes.reduce((sum, num, index) => {
          const usedMemoryRate = num / jsHeapSizeLimits[index]
          // 平稳值精确到整数百分位
          const stableValue = Number(usedMemoryRate.toFixed(2))
          maxUsedMemoryRate = Math.max(maxUsedMemoryRate, usedMemoryRate)
          usedMemoryRateStableValueMap[stableValue] = usedMemoryRateStableValueMap[stableValue]
            ? usedMemoryRateStableValueMap[stableValue] + 1
            : 1
          // 内存使用率稳定值
          if (usedMemoryRateStableValueCount < usedMemoryRateStableValueMap[stableValue]) {
            usedMemoryRateStableValueCount = usedMemoryRateStableValueMap[stableValue]
            usedMemoryRateStableValue = stableValue
          }
          return sum + usedMemoryRate
        }, 0) /
          count) *
          1000) |
        0
      result.maxUsedMemoryRate = (maxUsedMemoryRate * 1000) | 0
      result.usedMemoryRateStableValue = (usedMemoryRateStableValue * 1000) | 0
      //记录此刻采样数据
      Object.assign(this.snapshot, result)
      // 清空历史记录
      this.groupResult.jsHeapSizeLimits = []
      this.groupResult.usedJSHeapSizes = []
    } catch (e: any) {
      this.log(`memory:beforeUpdate:Error: ${e.message}`)
    }
  }
}

export default Memory
