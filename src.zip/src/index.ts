import _ from 'lodash'
import Base from './data/base'
import OsInfo from './data/os'
import Battery from './data/battery'
import NetworkSpeed from './data/networkSpeed'
import CpuComputePressure from './data/cpuComputePressure'
import Memory from './data/memory'
import RequestConcurrency from './data/request'
import DomMonitoring from './data/domMonitoring'
import WatchChange from './data/watchChange'
import Browser from './data/browser'
import Crash from './data/crash'
import FPS from './data/fps'

import { formatTime, isHeadlessBrowser } from './util'

import sendBaconReporter from './report'
import { MonitorConfig, KeyValueObj, CustomIndicator, ReportData, DurationIndicators, ReportDataTags } from './types'
type ExtendsClass<T, U extends T> = U
type DataObjType = ExtendsClass<Base, any>

// 系统指标数
const GROUP_SIZE = 200
// 自定义指标数
const Custom_GROUP_SIZE = 15

export class Core {
  // 系统指标
  private indicators: DataObjType[]
  // 系统维度
  private dimensions: DataObjType[]
  // 自定指标
  private customIndicators: CustomIndicator[] = []
  // 开始统计时间
  private startTime: string
  // 时间间隔类型自定义指标收集
  private durationIndicatorsCache = {} as { [key: string]: DurationIndicators }
  // 次数类自定义指标收集
  private countIndicatorsCache = {} as { [key: string]: DurationIndicators }
  // 配置信息，包括公共配置维度
  config: MonitorConfig
  constructor() {
    const self = this
    const battery = new Battery()
    // 系统通用指标
    self.indicators = [
      battery,
      new NetworkSpeed(),
      new Memory(),
      new CpuComputePressure(),
      new RequestConcurrency(),
      new DomMonitoring(),
      new WatchChange(),
      new Crash(),
      new FPS()
    ]
    // 系统通用维度
    self.dimensions = [new OsInfo(), new Browser(), battery]
  }
  async start(config: MonitorConfig) {
    const self = this
    self.config = config
    self.startTime = formatTime(new Date())
    const promises: Array<Promise<any>> = []
    if (isHeadlessBrowser()) return
    ;[...self.indicators, ...self.dimensions].forEach((item: DataObjType) => {
      item.config = config
      promises.push(item.init(self))
    })
    await Promise.all(promises)
    // 页面 beforeunload 监听
    const onBeforeunload = () => {
      self.reportAll()
    }
    window.addEventListener('beforeunload', onBeforeunload)
    //页面显示隐藏监听
    const onVisibilitychange = () => {
      const pageShow = document.visibilityState === 'visible' || !document.hidden
      ;[...self.indicators, ...self.dimensions].forEach((item: DataObjType) => {
        item.pageShow = pageShow
        item.onVisibilitychange(pageShow)
      })
    }
    document.addEventListener('visibilitychange', onVisibilitychange)
    window.addEventListener('unload', function unload() {
      ;[...self.indicators, ...self.dimensions].forEach((item: DataObjType) => {
        item.destroy()
      })
      window.removeEventListener('beforeunload', onBeforeunload)
      document.removeEventListener('visibilitychange', onVisibilitychange)
      window.removeEventListener('unload', unload)
    })
    // 开始指标采集
    requestAnimationFrame(function loop(time) {
      const tags = self.getSystemDimensions()
      let sum = 0
      // 暂时只需要更新指标，维度一般都不变
      self.indicators.forEach((item: DataObjType) => {
        sum += item.update(time, tags)
      })
      if (sum > GROUP_SIZE || self.customIndicators.length > Custom_GROUP_SIZE) {
        self.reportAll(false)
      }
      requestAnimationFrame(loop)
    })
  }
  // 通用自定义指标上报方法
  report(indicator: KeyValueObj, tags: KeyValueObj = {}) {
    if (Object.keys(indicator).length) {
      this.customIndicators.push({
        indicator: indicator,
        tags: { ...this.getSystemDimensions(), ...tags }
      })
    }
  }
  // 注册自定义全局维度
  registerCustomTags(tags: ReportDataTags) {
    if (tags && this.config) {
      this.config.tags = { ...this.config.tags, ...tags }
    }
  }
  // 时间类指标开始计时时间
  reportStartTime(linkId: string, indicatorName = '', tags: KeyValueObj = {}) {
    let item = this.durationIndicatorsCache[linkId]
    if (!item) {
      item = {
        indicator: indicatorName,
        value: Date.now(),
        tags
      }
      this.durationIndicatorsCache[linkId] = item
    } else {
      item.indicator = indicatorName || item.indicator
      item.value = Date.now()
      item.tags = { ...item.tags, ...tags }
    }
  }
  // 时间类指标统计结束
  reportEndTime(linkId: string, tags: KeyValueObj = {}) {
    const item = this.durationIndicatorsCache[linkId]
    if (item) {
      this.report(
        {
          [item.indicator]: Date.now() - item.value
        },
        { ...item.tags, ...tags }
      )
      delete this.durationIndicatorsCache[linkId]
    }
  }
  // 次数类指标上报
  reportCount(linkId: string, indicatorName = '', tags: KeyValueObj = {}) {
    let item = this.countIndicatorsCache[linkId]
    if (!item) {
      item = {
        indicator: indicatorName,
        value: 1,
        tags: { ...tags }
      }
      this.countIndicatorsCache[linkId] = item
    } else {
      item.value++
      item.indicator = indicatorName || item.indicator
      item.tags = { ...item.tags, ...tags }
    }
  }
  // 记数结束
  reportCountEnd(linkId = '', tags: KeyValueObj = {}) {
    const item = this.countIndicatorsCache[linkId]
    if (item) {
      this.report(
        {
          [item.indicator]: item.value
        },
        { ...item.tags, ...tags }
      )
      delete this.countIndicatorsCache[linkId]
    } else if (!linkId) {
      Object.keys(this.countIndicatorsCache).forEach(key => {
        const customIndicator = this.countIndicatorsCache[key]
        this.report(
          {
            [customIndicator.indicator]: customIndicator.value
          },
          { ...customIndicator.tags, ...tags }
        )
      })
      this.countIndicatorsCache = {}
    }
  }
  /**
   * 获取当前系统维度值
   */
  getSystemDimensions(): KeyValueObj {
    const self = this
    const { dimensions } = self
    const systemDimensions = dimensions.reduce((res, dimension) => {
      if (dimension.ready) {
        const { snapshot } = dimension
        Object.keys(snapshot).forEach(key => {
          if (`${snapshot[key]}`.length) {
            res[key] = snapshot[key]
          }
        })
      }
      return res
    }, {} as KeyValueObj)
    return { ...systemDimensions, ...this.getComputedTags() }
  }
  // 获取当前时刻所有指标值快照
  getSnapshot(): KeyValueObj {
    const self = this
    const { indicators } = self
    return indicators.reduce<KeyValueObj>((res, indicator) => {
      if (indicator.ready) {
        const { snapshot } = indicator
        res = { ...res, ...snapshot }
      }
      return res
    }, {} as KeyValueObj)
  }
  private getComputedTags() {
    const tags = this.config ? this.config.tags : {}
    return Object.keys(tags).reduce((res, key) => {
      if (tags[key] instanceof Function) {
        res[key] = tags[key]()
      } else {
        res[key] = tags[key]
      }
      return res
    }, {} as KeyValueObj)
  }
  private reportAll(unload = true) {
    const self = this
    // 刷新页面之前上报一次次数指标
    unload && self.reportCountEnd()
    const reportList = self.getReportList()
    this.batchReport(reportList, unload)
  }
  // 获取批量上报的数据结构
  private getReportList(): ReportData[] {
    const self = this
    const { indicators } = self
    // 系统指标
    const systemIndicators = indicators.reduce((res, indicator) => {
      const { result } = indicator
      Object.keys(result).forEach(key => {
        if (result[key].length) {
          result[key].forEach(indicatorsItem => {
            res.push({
              indicator: { [key]: indicatorsItem.value },
              tags: indicatorsItem.tags
            })
          })
        }
      })
      return res
    }, [] as CustomIndicator[])

    const indicatorGroup = self.getIndicatorGroup(systemIndicators)
    return indicatorGroup
  }
  // 获取自定义指标分组,维度相同的指标分一组
  private getIndicatorGroup(systemIndicators: CustomIndicator[]): ReportData[] {
    try {
      const self = this
      const { customIndicators } = self
      const customIndicatorsList: {
        tags: KeyValueObj
        indicators: ReportData['indicators']
      }[] = []
      const dataList = [...systemIndicators, ...customIndicators]
      dataList.forEach((item: CustomIndicator) => {
        const { indicator, tags } = item
        let group = customIndicatorsList.find(groupItem =>
          _.isEqual(groupItem.tags, tags)
        ) as typeof customIndicatorsList[number]
        if (!group) {
          group = {
            tags,
            indicators: {}
          }
          customIndicatorsList.push(group)
        }
        Object.keys(indicator).forEach(indicatorKey => {
          if (group.indicators[indicatorKey]) {
            group.indicators[indicatorKey].push(indicator[indicatorKey])
          } else {
            group.indicators[indicatorKey] = [indicator[indicatorKey]]
          }
        })
      })
      return customIndicatorsList
    } catch (e) {
      return []
    }
  }
  private extraData(unload: boolean): Record<string, string | number> {
    const start = this.startTime
    const reportTime = formatTime(new Date())
    return {
      startTime: start,
      endTime: reportTime,
      unload: unload ? 1 : 0
    }
  }
  // 上报完成后清除历史记录
  private clearLog() {
    const self = this
    self.customIndicators = []
    self.indicators.forEach((item: DataObjType) => {
      Object.keys(item.result).forEach(key => {
        item.result[key] = []
      })
    })
    // 过滤掉单次上报的指标
    self.indicators = self.indicators.filter((item: DataObjType) => {
      return !item.singleReport
    })
  }
  // 分批上报
  private batchReport(reportList: ReportData[], unload: boolean) {
    try {
      const self = this
      reportList.forEach((item: ReportData) => {
        sendBaconReporter(unload, {
          appKey: self.config.appKey,
          tags: item.tags,
          indicators: item.indicators,
          extraData: self.extraData(unload)
        })
      })
      self.clearLog()
      this.startTime = formatTime(new Date())
    } catch (e) {}
  }
}
let core = {
  async start(config: MonitorConfig) {},
  report(indicator: KeyValueObj, tags: KeyValueObj = {}) {},
  getSystemDimensions(): KeyValueObj {
    return {}
  },
  reportStartTime(linkId: string, indicatorName = '', tags: KeyValueObj = {}) {},
  reportEndTime(linkId: string, tags: KeyValueObj = {}) {},
  reportCountEnd(linkId = '', tags: KeyValueObj = {}) {},
  reportCount(linkId: string, indicatorName = '', tags: KeyValueObj = {}) {}
} as Core
try {
  core = new Core()
} catch (e: any) {}
export default core
