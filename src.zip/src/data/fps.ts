import Base from './base'
import { pageStable } from '../util'

export type FpsInfo = {
  fpsTP80: number
  fpsMax: number
  fpsTP99: number
  fpsTP95: number
  fpsTP90: number
  fpsAvg: number
  fpsMin: number
  fpsFluencyRate: number
}

const DefaultIndicatorValue = {
  fpsTP80: -1,
  fpsMax: -1,
  fpsTP99: -1,
  fpsTP95: -1,
  fpsTP90: -1,
  fpsAvg: -1,
  fpsMin: -1,
  fpsFluencyRate: -1
} as FpsInfo

// 系统信息采集
class FPS extends Base {
  updateTime = 1000 * 60
  groupResult = new Array(61).fill(0)
  // 特殊场景需要停止统计
  stop = false
  readyTimer: ReturnType<typeof setTimeout>
  constructor() {
    super({ ...DefaultIndicatorValue })
    this.start()
    this.proxyBrowserEfect()
  }

  private async start() {
    try {
      const self = this
      let lastTime = 0
      // 页面稳定后开始统计
      await pageStable
      requestAnimationFrame(function loop(time) {
        if (lastTime === 0) {
          lastTime = time
        } else {
          const elapsed = time - lastTime
          const fps = Math.min(Math.max(1000 / elapsed, 1), 60) | 0
          lastTime = time
          !self.stop && self.groupResult[fps]++
        }
        requestAnimationFrame(loop)
      })
      this.onReady()
    } catch (e: any) {
      this.log(`FPS:init:Error: ${e.message}`)
    }
  }
  onReady() {
    this.readyTimer = setTimeout(() => {
      if (this.groupResult.length > 20) {
        // 最少20帧才开始统计上报
        this.ready = true
      } else {
        this.onReady()
      }
    }, 3000)
  }
  onVisibilitychange(pageShow) {
    pageShow && this.proxyEfect()
  }
  // 浏览器一些特殊行为导致的副作用兼容
  private proxyBrowserEfect() {
    const self = this
    const onBeforeunload = function () {
      self.proxyEfect()
    }
    window.addEventListener('beforeunload', onBeforeunload)
    const alert = window.alert
    window.alert = function (...args) {
      self.proxyEfect()
      return alert.apply(window, args)
    }
    const confirm = window.confirm
    window.confirm = function (...args) {
      self.proxyEfect()
      return confirm.apply(window, args)
    }
    self.destroy = function () {
      window.removeEventListener('beforeunload', onBeforeunload)
      self.readyTimer && clearTimeout(self.readyTimer)
    }
  }
  private proxyEfect() {
    const self = this
    self.stop = true
    setTimeout(() => {
      self.stop = false
    }, 1000)
  }
  beforeUpdate(): void {
    const self = this
    const snapshot = { ...DefaultIndicatorValue } as FpsInfo
    const fpsCount: number = self.groupResult.reduce((sum, count) => sum + count, 0)
    const tp99count: number = fpsCount * 0.99
    const tp90count: number = fpsCount * 0.9
    const tp95count: number = fpsCount * 0.95
    const tp80count: number = fpsCount * 0.8
    let max = 0,
      min = 60
    // 平均值
    snapshot.fpsAvg =
      (self.groupResult.reduce((sum, count, fps) => {
        if (count > 0) {
          min = Math.min(fps, min)
          max = Math.max(fps, max)
        }
        return sum + count * fps
      }, 0) /
        fpsCount) |
      0
    snapshot.fpsMax = max
    snapshot.fpsMin = min
    let tpCount = 0,
      fpsFluencyRateCount = 0
    while (self.groupResult.length) {
      const fps = self.groupResult.length - 1
      // fps大于20 认为流程
      if (fps > 20) {
        fpsFluencyRateCount += self.groupResult[fps]
      }
      tpCount += self.groupResult.pop()
      if (tpCount >= tp99count && snapshot.fpsTP99 === -1) snapshot.fpsTP99 = fps
      if (tpCount >= tp95count && snapshot.fpsTP95 === -1) snapshot.fpsTP95 = fps
      if (tpCount >= tp90count && snapshot.fpsTP90 === -1) snapshot.fpsTP90 = fps
      if (tpCount >= tp80count && snapshot.fpsTP80 === -1) snapshot.fpsTP80 = fps
    }
    snapshot.fpsFluencyRate = ((fpsFluencyRateCount / fpsCount) * 1000) | 0
    self.snapshot = snapshot
    self.groupResult = new Array(61).fill(0)
  }
}

export default FPS
