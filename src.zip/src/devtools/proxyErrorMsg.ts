import reportError from './reportError'
export enum SEC_CATEGORY {
  script = '[script]',
  consoleError = '[consoleError]',
  unhandledrejection = '[unhandledrejection]',
  resourceError = '[resourceError]'
}
export type ErrorItem<T extends SEC_CATEGORY> = {
  sec_category: T
  content: string
} & (T extends SEC_CATEGORY.script
  ? {
      errorMsg: string
      resourceUrl: string
      rowNum: number
      colNum: number
    }
  : {})

export default class ProxyErrorMsg {
  static proxyErrorMsgList: ErrorItem<SEC_CATEGORY>[] = []
  static init() {
    try {
      // proxy onerror
      const onerror = window.onerror
      window.onerror = (...args) => {
        onerror && onerror.apply(window, args)
        // @ts-ignore
        this.parseWindowError(...args)
      }
      // proxy console.error
      const error = window.console.error
      window.console.error = (...args) => {
        error && error.apply(window.console, args)
        this.parseConsoleError(...args)
      }
      // proxy onunhandledrejection
      const onUnhandledrejection = function (event: Event) {
        ProxyErrorMsg.parsePromiseUnhandled(event)
      }
      window.addEventListener('unhandledrejection', onUnhandledrejection, true)

      // proxy listener error
      const onError = (event: Event) => {
        this.handleResourceLoadError(event)
      }
      // 部分错误在冒泡阶段无法获取，因此这里监听捕获阶段
      window.addEventListener('error', onError, true)
      window.addEventListener('unload', () => {
        window.removeEventListener('unhandledrejection', onUnhandledrejection, true)
        window.removeEventListener('error', onError, true)
      })
      this.init = () => {}
    } catch (e: any) {
      reportError(`ProxyErrorMsg:init:Error: ${e.message}`)
    }
  }
  static parseWindowError(errorMsg: string | Event, resourceUrl: string, rowNum: number, colNum: number, error: Error) {
    try {
      let errorObj: ErrorItem<SEC_CATEGORY.script> = {
        sec_category: SEC_CATEGORY.script,
        errorMsg: `${errorMsg}`,
        content: '',
        resourceUrl,
        rowNum,
        colNum
      }
      if (error && error.stack) {
        errorObj = this._processError(error, resourceUrl, rowNum, colNum)
      }
      this.proxyErrorMsgList.push(errorObj)
    } catch (e: any) {
      reportError(`ProxyErrorMsg:parseWindowError:Error: ${e.message}`)
    }
  }
  static _processError(error: Error, resourceUrl: string, rowNum = 0, colNum = 0): ErrorItem<SEC_CATEGORY.script> {
    const resourceMatch = (error.stack || '').match('https?://[^\n]+'),
      resourceLine = resourceMatch ? `${resourceMatch[0]}` : '',
      regName = /https?:\/\/(\S)+\.js/,
      urlMatch = resourceLine.match(regName) || [],
      url = urlMatch[0] || '',
      lines = resourceLine.match(':(\\d+):(\\d+)') || [0, 0, 0]
    return {
      sec_category: SEC_CATEGORY.script,
      errorMsg: error.message || error.name || '',
      content: error.stack || '',
      resourceUrl: url || resourceUrl,
      rowNum: +lines[1] || rowNum,
      colNum: +lines[2] || colNum
    }
  }
  static parseConsoleError(...args) {
    try {
      if (!args || !args.length) return
      const result: string[] = []
      for (let i = 0; i < args.length; i++) {
        const msgItem = args[i]
        if (msgItem) {
          let msg = ''
          if (typeof msgItem === 'string') {
            msg = msgItem
          } else if (msgItem instanceof window.Error) {
            msg = msgItem.stack || msgItem.message || ''
          } else if (msgItem instanceof window.ErrorEvent) {
            msg = (msgItem.error && (msgItem.error.stack || msgItem.error.message)) || msgItem.message || ''
          } else {
            msg = JSON.stringify(msgItem)
          }
          result.push(msg)
        }
      }
      result.length &&
        this.proxyErrorMsgList.push({
          sec_category: SEC_CATEGORY.consoleError,
          content: result.join(' ')
        })
    } catch (e: any) {
      reportError(`ProxyErrorMsg:parseConsoleError:Error: ${e.message}`)
    }
  }
  static parsePromiseUnhandled(event: Event) {
    if (event && 'unhandledrejection' === event.type) {
      try {
        // @ts-ignore
        const error = event.reason
        if (error) {
          let content = error
          if (error instanceof Error) {
            content = error.stack || error.toString() || ''
          }
          this.proxyErrorMsgList.push({
            sec_category: SEC_CATEGORY.unhandledrejection,
            content
          })
        }
      } catch (e: any) {
        reportError(`ProxyErrorMsg:parsePromiseUnhandled:Error: ${e.message}`)
      }
    }
  }
  static getFormatErrorList(): string[] {
    try {
      const set = new Set()
      const errorList: ErrorItem<SEC_CATEGORY>[] = []
      return this.proxyErrorMsgList
        .filter((item: ErrorItem<SEC_CATEGORY>) => {
          const key = `${item.content}-${item.sec_category}`
          if (!set.has(key)) {
            set.add(key)
            if (item.sec_category !== SEC_CATEGORY.consoleError) {
              const error = item as ErrorItem<SEC_CATEGORY>
              errorList.push(error)
            }
            return true
          }
          return false
        })
        .filter(item => {
          // 重复的情况下优先过滤掉consoleError 错误类型的错误
          if (
            item.sec_category === SEC_CATEGORY.consoleError &&
            errorList.some(error => error.content === item.content)
          ) {
            return false
          }
          return true
        })
        .map((item: ErrorItem<SEC_CATEGORY>) => {
          if (item.sec_category === SEC_CATEGORY.script) {
            const scriptError = item as ErrorItem<SEC_CATEGORY.script>
            return `${scriptError.sec_category}: ${scriptError.content || scriptError.errorMsg} ${
              scriptError.resourceUrl ? `at ${scriptError.resourceUrl}:${scriptError.rowNum}:${scriptError.colNum}` : ''
            }`
          } else {
            return `${item.sec_category}:${item.content}`
          }
        })
    } catch (e: any) {
      reportError(`ProxyErrorMsg:getFormatErrorList:Error: ${e.message}`)
      return []
    }
  }
  static handleResourceLoadError(event: Event) {
    const target = event.target
    if (
      target instanceof HTMLScriptElement ||
      target instanceof HTMLLinkElement ||
      target instanceof HTMLImageElement
    ) {
      // @ts-ignore
      const url = target.src || target.href
      const locationHref = window.location.href
      if (locationHref && locationHref && 0 !== locationHref.indexOf(url)) {
        const nodeName = (target.nodeName || '').toLowerCase()
        if (nodeName) {
          if (url) {
            const xpath = this.getXPath(target)
            const content = url + (xpath ? '\n' + xpath : '')
            this.proxyErrorMsgList.push({
              sec_category: SEC_CATEGORY.resourceError,
              content
            })
          }
        }
      }
    }
  }
  static getXPath(target, deep = 3) {
    try {
      const id = target.id ? '#' + target.id : ''
      const className =
        'string' === typeof target.className && target.className ? '.' + target.className.split(' ').join('.') : ''
      const nodeName = 'string' === typeof target.nodeName ? target.nodeName.toLowerCase() : ''
      const xpath = nodeName + id + className
      return target.parentNode && target.parentNode.nodeName && deep - 1 > 0
        ? this.getXPath(target.parentNode, deep - 1) + ' > ' + xpath
        : xpath
    } catch (e: any) {
      reportError(`ProxyErrorMsg:getXPath:Error: ${e.message}`)
      return ''
    }
  }
}
