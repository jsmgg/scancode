import Base from './base'
import { pageStable, inIFrame } from '../util'

const TestImg = [
  { src: 'https://s3plus.sankuai.com/efficiency-tool/networkTest2.jpg', size: 57935 },
  { src: 'https://s3plus.sankuai.com/efficiency-tool/networkTest1.jpg', size: 75291 },
  { src: 'https://s3plus.sankuai.com/efficiency-tool/networkTest.jpg', size: 746047 }
]
// 网速统计 KB/S
class NetworkSpeed extends Base {
  updateTime = 1000 * 60 * 3
  constructor() {
    // 网速单位kb/s
    super({ networkSpeed: 0 })
  }

  async init() {
    const self = this
    if (inIFrame()) return
    //DOMContentLoaded
    await pageStable
    self.testSpeed()
    self.loop()
  }
  private loop() {
    setTimeout(() => {
      this.pageShow && this.testSpeed()
      this.loop()
    }, this.updateTime)
  }
  // 测速
  private async testSpeed() {
    const self = this
    const snapshot = self.snapshot as { networkSpeed: number }
    let request: Promise<number[]> = Promise.resolve([])
    if (!performance) return
    const key = Date.now()
    TestImg.forEach(item => {
      request = request.then(arr => {
        return self.loadImg(`${item.src}?t=${key}`, item.size).then(speed => {
          arr.push(speed)
          return arr
        })
      })
    })
    return await request.then(arr => {
      snapshot.networkSpeed = (arr.reduce((a, b) => a + b) / arr.length) | 0
      self.ready = true
    })
  }
  private loadImg(src: string, size: number): Promise<number> {
    let timer
    const start = performance.now()
    return new Promise(res => {
      const img = new Image()
      img.onload = () => {
        clearTimeout(timer)
        const time = performance.now() - start
        res((size / 1024 / time) * 1000)
      }
      timer = setTimeout(() => {
        // 超时认为 网速为1kb
        res(1)
        img.removeAttribute('src')
      }, this.updateTime - 3000)
      img.src = src
    })
  }
}

export default NetworkSpeed
