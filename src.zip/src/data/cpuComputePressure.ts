import _ from 'lodash'
import Base from './base'
import { inIFrame } from '../util'

const PressureObserverTypes = {
  nominal: 1,
  fair: 2,
  serious: 3,
  critical: 4
}
// cpu计算压力统计
class CpuComputePressure extends Base {
  updateTime = 1000 * 60
  groupResult: number[] = []

  constructor() {
    super({ cpuComputePressure: 0 })
  }

  async init() {
    //@ts-ignore
    if ('PressureObserver' in window && typeof window.PressureObserver === 'function' && !inIFrame()) {
      try {
        //@ts-ignore
        if (!document.featurePolicy.allowedFeatures().includes('compute-pressure')) return
        //@ts-ignore
        const observer = new PressureObserver(records => {
          if (!this.pageShow) return
          const lastRecord = records[records.length - 1] || { state: '' }
          this.groupResult.push(PressureObserverTypes[lastRecord.state.toLowerCase()] || 0)
          this.ready = true
        })
        observer.observe('cpu', { sampleInterval: 16 })
        this.destroy = function () {
          observer.disconnect()
        }
      } catch (e: any) {
        this.log(`cpuComputePressure:Error:${e.message}`)
      }
    }
  }
  beforeUpdate(): void {
    const snapshot = this.snapshot as { cpuComputePressure: number }
    snapshot.cpuComputePressure = this.groupResult.length
      ? (_.max<number>(this.groupResult) as number)
      : snapshot.cpuComputePressure
    this.groupResult = []
  }
}

export default CpuComputePressure
