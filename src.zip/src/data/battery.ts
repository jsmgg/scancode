import Base from './base'
import { inIFrame } from '../util'
export type BatteryInfo = {
  batteryLevel: number
  batteryCharging: number
}
// 电量和充电状态统计
class Battery extends Base {
  // 笔记本电池平均续航3.5小时 平均两分钟掉1%电量
  updateTime = 1000 * 60 * 2
  executed = false
  constructor() {
    super({ batteryLevel: 0, batteryCharging: 0 } as BatteryInfo)
  }

  async init() {
    // @ts-ignore
    if ('getBattery' in navigator && typeof navigator.getBattery === 'function' && !inIFrame() && !this.executed) {
      try {
        const self = this
        self.executed = true
        // @ts-ignore
        const battery = await Promise.race([
          // @ts-ignore
          navigator.getBattery(),
          new Promise((_, rej) => setTimeout(() => rej('navigator.getBattery timeout'), 2000))
        ]) // 特殊场景下navigator.getBattery() 会一直pending
        self.updateBatteryStatus(battery)
        const onChange = () => self.updateBatteryStatus(battery)
        battery.addEventListener('levelchange', onChange)
        battery.addEventListener('chargingchange', onChange)
        self.destroy = function () {
          battery.removeEventListener('levelchange', onChange)
          battery.removeEventListener('chargingchange', onChange)
        }
      } catch (e: any) {
        this.log(`battery:Error:${e.message || e}`)
      }
    }
  }
  // 更新当前电量信息
  private updateBatteryStatus(battery) {
    const { level, charging } = battery
    const snapshot = this.snapshot as BatteryInfo
    snapshot.batteryLevel = ((level || 0) * 100) | 0
    snapshot.batteryCharging = charging ? 1 : 0
    this.ready = true
  }
}

export default Battery
