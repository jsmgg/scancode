import WebProfiling from '../webProfiling/core'
import proxyErrorMsg from './proxyErrorMsg'
import reportError from './reportError'
const StartTime = Date.now()
import { getPlugins } from './plugin'
const MOD_ID = `debug-container-${Math.random().toString(16).slice(2, 8)}`
type Item = { label: string; key: string; unit?: string; inline?: boolean }
const CSS_STYLE = `
#${MOD_ID}{
  position: fixed;
  right:12px;
  bottom:12px;
  border-radius: 6px;
  background: #000;
  z-index: 2147483647;
  color:#0f0;
  pointer-events: auto;
  border:1px solid #0f0;
  overflow-y: auto;
}
#${MOD_ID} .header{
  display: flex;
  padding-top: 12px;
}
#${MOD_ID} .header .title{
  padding-left: 60px;
  text-align: center;
  flex: 1;
  font-weight: bold;
}
#${MOD_ID} .header .close{
  width: 60px;
  text-align: center;
  cursor: pointer;
  pointer-events: auto;
}
#${MOD_ID} .header .close:hover{
  opacity: 0.8;
}
#${MOD_ID} ul{
  margin: 0;
  padding: 12px;
  width: 524px;
  flex-wrap: wrap;
  display: flex;
  flex-direction: row;
}
#${MOD_ID} ul li.item{
  width: 250px;
  display:flex;
  flex-direction: row;
  align-items: center;
}
#${MOD_ID} ul li.inline{
  width: 500px;
}
#${MOD_ID} ul li.item .label{
  width: 110px;
  text-align:right;
  padding-right:12px;
}
#${MOD_ID} ul li.item .value{
  flex:1;
  word-break: break-all;
}
`
const CONFIG = [
  { label: '灰度cell', key: 'grayCell', inline: true },
  { label: 'talos灰度版本', key: 'grayCellTalosVersion' },
  { label: '灰度类型', key: 'grayType' },
  { label: '构建时间', key: 'webVersion' },
  { label: '用户mis', key: 'misId' },
  { label: '浏览器类型', key: 'browser' },
  { label: '浏览器版本', key: 'browserVersion' },
  { label: '系统', key: 'systemOs' },
  { label: '系统版本', key: 'systemOsVersion' },
  { label: 'fps均值', key: 'fpsAvg' },
  { label: '流畅率', key: 'fpsFluencyRate', unit: '%' },
  { label: '可用内存', key: 'jsHeapSizeLimit', unit: 'MB' },
  { label: '已用内存', key: 'usedJSHeapSize', unit: 'MB' },
  { label: '网速', key: 'networkSpeed', unit: 'KB' },
  { label: 'cpu压力', key: 'cpuComputePressure' },
  { label: '高危插件', key: 'plugins' },
  { label: '系统运行时长', key: 'runTime', unit: '秒' },
  { label: '报错信息', key: 'errorMsgs', inline: true }
] as Item[]

export default class Tpl {
  static onload = false
  static isShow(): boolean {
    return !!document.getElementById(MOD_ID)
  }
  static async open() {
    try {
      const options = await this.getData()
      this.render(options)
    } catch (e: any) {
      reportError(`Tpl:open:Error: ${e.message}`)
    }
  }
  static render(options: Record<string, string | number>) {
    this.renderStyle()
    this.renderTpl(options)
    this.onload = true
  }
  static renderTpl(options: Record<string, string | number>) {
    let container = document.getElementById(MOD_ID)
    if (!container) {
      container = document.createElement('div')
      container.id = MOD_ID
      document.body.appendChild(container)
      container.addEventListener('click', this.onClose)
    }
    container.style.maxHeight = window.innerHeight - 24 + 'px'
    const tpl = [
      '<div class="header"><div class="title">调试信息</div><div name="close" class="close">关闭</div></div>'
    ]
    tpl.push(
      CONFIG.reduce((str, item: Item) => {
        let value = options[item.key]
        if (value && item.unit === '%') {
          value = (Number(value) / 10) | 0
        }
        return `
        ${str}<li class="item ${item.inline ? 'inline' : ''}">
        <div class="label">${item.label}:</div>
        <div class="value">${value || '--'}${item.unit || ''}</div>
        </li>
      `
      }, '<ul>')
    )
    tpl.push('</ul>')
    container.innerHTML = tpl.join('')
  }
  static renderStyle() {
    if (this.onload) return
    const styleSheet = document.createElement('style')
    styleSheet.setAttribute('type', 'text/css')
    styleSheet.textContent = CSS_STYLE
    document.head.appendChild(styleSheet)
  }
  static onClose(e) {
    if (e && e.target && e.target.getAttribute('name') === 'close') {
      Tpl.close()
    }
  }
  static close() {
    const container = document.getElementById(MOD_ID)
    if (container) {
      container.removeEventListener('click', this.onClose)
      document.body.removeChild(container)
    }
  }
  static async getData(): Promise<Record<string, string | number>> {
    const grayCellConfig = window.grayCellConfig || {}
    const options = {
      ...WebProfiling.getSystemDimensions(),
      ...WebProfiling.getSnapshot(),
      grayCellTalosVersion: grayCellConfig.version || '',
      grayType: grayCellConfig.grayType || '',
      runTime: ((Date.now() - StartTime) / 1000) | 0
    } as Record<string, string | number>
    const plugins = options.browser === 'Chrome' ? await getPlugins() : []
    options.plugins = plugins.join('、')
    options.errorMsgs = proxyErrorMsg.getFormatErrorList().reduce((res, msg, i) => {
      return `${res}${i + 1}、${this.escapeHtml(msg)}<br/>`
    }, '')
    return CONFIG.reduce((res, item: Item) => {
      res[item.key] = options[item.key]
      return res
    }, {})
  }
  static escapeHtml(str: string) {
    const htmlEscapes = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;'
    }

    return str.replace(/[&<>"']/g, char => htmlEscapes[char])
  }
}
