export const isProd = ['production'].includes(window.__ENV__)
export const RAPTOR_HOST = isProd ? 'catfront.dianping.com' : 'catfront.51ping.com'
import { ReportData } from '../types'
/**
 *
 * @param params 上报tags数据
 * @returns value 格式化为string 类型
 */
function transformParamsToTags(params: Record<string, any>) {
  const paramsTag = {}
  Object.keys(params).forEach(key => {
    paramsTag[key] = String(params[key])
  })
  return paramsTag
}

export function normalizeSendBeaconParam(
  indicators: ReportData['indicators'],
  params: Record<string, string | number>,
  extraData: Record<string, string | number>
) {
  const paramsTag = transformParamsToTags(params)
  // 秒级时间戳
  const ts = Math.floor(Date.now() / 1000)
  const reportParam = {
    kvs: Object.keys(indicators).reduce((res, key) => {
      res[key] = indicators[key]
      return res
    }, {}),
    tags: { ...paramsTag },
    extraData: JSON.stringify(extraData),
    ts
  }
  return JSON.stringify(reportParam)
}

export function formatTime(date: Date | number, format = 'yyyy-MM-dd HH:mm:ss', invalidText = '--'): string {
  if (+date <= 0) {
    return invalidText
  }
  const WeekTextMap = ['天', '一', '二', '三', '四', '五', '六']
  const dt = new Date(+date)
  const parse = {
    yyyy: dt.getFullYear(),
    MM: dt.getMonth() + 1,
    dd: dt.getDate(),
    HH: dt.getHours(),
    mm: dt.getMinutes(),
    ss: dt.getSeconds(),
    星期: `星期${WeekTextMap[dt.getDay()]}`,
    YYYY: 0,
    DD: 0
  }

  parse.YYYY = parse.yyyy
  parse.DD = parse.dd

  Object.entries(parse).forEach(([k, v]) => {
    parse[k] = String(v).padStart(2, '0')
  })

  return Object.entries(parse).reduce((prev, [k, v]) => {
    return prev.replace(k, `${v}`)
  }, format)
}

export function getDomNumber() {
  return document.getElementsByTagName('*').length
}

export function isHeadlessBrowser(): boolean {
  // chrome 驱动的无头浏览器
  const isHeadlessChrome = /HeadlessChrome/.test(window.navigator.userAgent)
  // selenium 爬虫驱动的无头浏览器
  const isSeleniumDriver = !!window.navigator.webdriver
  return isHeadlessChrome || isSeleniumDriver
}

export function inIFrame() {
  return window.top !== window
}

export const pageStable = new Promise(res => {
  const maxTime = 3000
  window.addEventListener('load', function load() {
    let timer: ReturnType<typeof setTimeout>
    const startTime = performance.now(),
      domNumber = getDomNumber()
    const loop = function () {
      timer && clearTimeout(timer)
      timer = setTimeout(() => {
        const newDomNumber = getDomNumber()
        if (newDomNumber === domNumber || performance.now() - startTime > maxTime) {
          res(true)
        } else {
          loop()
        }
      }, 500)
    }
    loop()
    window.removeEventListener('load', load)
  })
}) as Promise<boolean>
